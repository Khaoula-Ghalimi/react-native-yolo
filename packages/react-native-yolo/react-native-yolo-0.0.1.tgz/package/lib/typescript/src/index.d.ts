import type { Yolo as YoloSpec } from './specs/yolo.nitro';
export declare const Yolo: YoloSpec;
//# sourceMappingURL=index.d.ts.map